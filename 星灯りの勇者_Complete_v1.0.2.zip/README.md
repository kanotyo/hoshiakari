# 星灯りの勇者 — Complete Edition

ブラウザだけで遊べる、全5章構成のレトロJRPGです。外部API・外部素材・ビルド作業は必要ありません。

## 遊び方

`index.html` をWebサーバーから開いてください。PCでは矢印キー/WASDで移動、Enter/Space/Zで決定、Esc/Xでメニューを開きます。スマートフォンでは画面下の十字キーとAボタンを使います。

セーブデータはブラウザの `localStorage` に保存されます。「章から遊ぶ」では各章を推奨能力で開始できます。

## ローカル起動

VS CodeのLive Serverなど、任意の静的Webサーバーでこのフォルダを公開します。PWAとオフライン動作は `file://` ではなく `http://localhost` またはHTTPS環境で有効になります。

## GitHub Pages

リポジトリのルートへ全ファイルを置き、GitHubの Settings → Pages で `Deploy from a branch`、対象ブランチの `/ (root)` を選びます。相対パスのみを使用しているため、プロジェクトページでも動作します。

## 内容

- 全5章の物語とエンディング
- ターン制コマンド戦闘、ボス5体、成長・アイテム・敗北復帰
- 自動/手動セーブ、章セレクト
- キーボード、タッチ操作、iPhoneのセーフエリア・横画面対応
- PWA、オフラインキャッシュ、GitHub Pages対応

Version 1.0.2
